<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Authentication Language Lines
    |--------------------------------------------------------------------------
    |
    | The following language lines are used during authentication for various
    | messages that we need to display to the user. You are free to modify
    | these language lines according to your application's requirements.
    |
    */

    'dashboard' => 'ড্যাশবোর্ড',
    // 'sidebarslot1' => '',
    // 'sidebarslot2' => '',
    'member' => 'সাদারন সদস্য',
    'admin' => 'এডমিন',
    'volunteer' => 'ভলন্টিয়ার',
    'donor' => 'দাতা',
    'donar' => 'গ্রহীতা',
    'list' => 'তালিকা'

];
