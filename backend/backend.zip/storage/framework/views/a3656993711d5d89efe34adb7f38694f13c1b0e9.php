<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title><?php echo e(config('app.name', 'Laravel')); ?></title>
	<!-- core:css -->
	<link rel="stylesheet" href="<?php echo e(asset('backend/assets/vendors/core/core.css')); ?>">
	<!-- endinject -->
  <!-- plugin css for this page -->
	<!-- end plugin css for this page -->
	<!-- inject:css -->
	<link rel="stylesheet" href="<?php echo e(asset('backend/assets/fonts/feather-font/css/iconfont.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('backend/assets/vendors/flag-icon-css/css/flag-icon.min.css')); ?>">
	<!-- endinject -->
  <!-- Layout styles -->
	<link rel="stylesheet" href="<?php echo e(asset('backend/assets/css/demo_1/style.css')); ?>">
  <!-- End layout styles -->
  <link rel="shortcut icon" href="<?php echo e(asset('backend/assets/images/favicon.png')); ?>" />
</head>
<body>
	<div class="main-wrapper">
        <?php echo $__env->yieldContent('content'); ?>
	</div>

	<!-- core:js -->
	<script src="<?php echo e(asset('backend/assets/vendors/core/core.js')); ?>"></script>
	<!-- endinject -->
  <!-- plugin js for this page -->
	<!-- end plugin js for this page -->
	<!-- inject:js -->
	<script src="<?php echo e(asset('backend/assets/vendors/feather-icons/feather.min.js')); ?>"></script>
	<script src="<?php echo e(asset('backend/assets/js/template.js')); ?>"></script>
	<!-- endinject -->
  <!-- custom js for this page -->
	<!-- end custom js for this page -->
</body>
</html>
<?php /**PATH C:\xampp\htdocs\work\manobota\backend\resources\views/layouts/app.blade.php ENDPATH**/ ?>