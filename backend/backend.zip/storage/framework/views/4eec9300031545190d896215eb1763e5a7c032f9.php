<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta http-equiv="X-UA-Compatible" content="ie=edge">
	<title><?php echo $__env->yieldContent('title'); ?></title>
	<!-- core:css -->
	<link rel="stylesheet" href="<?php echo e(asset('backend/assets/vendors/core/core.css')); ?>">
	<!-- endinject -->
  <!-- plugin css for this page -->
  <link rel="stylesheet" href="<?php echo e(asset('backend/assets/vendors/bootstrap-datepicker/bootstrap-datepicker.min.css')); ?>">
	<!-- end plugin css for this page -->
	<!-- inject:css -->
	<link rel="stylesheet" href="<?php echo e(asset('backend/assets/fonts/feather-font/css/iconfont.css')); ?>">
	<link rel="stylesheet" href="<?php echo e(asset('backend/assets/vendors/flag-icon-css/css/flag-icon.min.css')); ?>">
	<!-- endinject -->
  <!-- Layout styles -->
	<link rel="stylesheet" href="<?php echo e(asset('backend/assets/css/demo_1/style.css')); ?>">
  <!-- End layout styles -->
  <link rel="shortcut icon" href="<?php echo e(asset('backend/assets/images/favicon.png')); ?>" />
    <?php echo $__env->yieldPushContent('css'); ?>
</head>
<body>
	<div class="main-wrapper">

        <!-- partial:partials/_sidebar.html -->
        <?php echo $__env->make('backend.layouts.partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
		<!-- partial -->

		<div class="page-wrapper">

            <?php echo $__env->make('backend.layouts.partials.navbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

			<div class="page-content">

                <?php echo $__env->yieldContent('content'); ?>

			</div>

			<!-- partial:partials/_footer.html -->
			<?php echo $__env->make('backend.layouts.partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
			<!-- partial -->

		</div>
	</div>

	<!-- core:js -->
  <script src="<?php echo e(asset('backend/assets/vendors/core/core.js')); ?>"></script>
	<!-- endinject -->
  <!-- plugin js for this page -->
  <script src="<?php echo e(asset('backend/assets/vendors/chartjs/Chart.min.js')); ?>"></script>
  <script src="<?php echo e(asset('backend/assets/vendors/jquery.flot/jquery.flot.js')); ?>"></script>
  <script src="<?php echo e(asset('backend/assets/vendors/jquery.flot/jquery.flot.resize.js')); ?>"></script>
  <script src="<?php echo e(asset('backend/assets/vendors/bootstrap-datepicker/bootstrap-datepicker.min.js')); ?>"></script>
  <script src="<?php echo e(asset('backend/assets/vendors/apexcharts/apexcharts.min.js')); ?>"></script>
  <script src="<?php echo e(asset('backend/assets/vendors/progressbar.js/progressbar.min.js')); ?>"></script>
	<!-- end plugin js for this page -->
	<!-- inject:js -->
	<script src="<?php echo e(asset('backend/assets/vendors/feather-icons/feather.min.js')); ?>"></script>
	<script src="<?php echo e(asset('backend/assets/js/template.js')); ?>"></script>
	<!-- endinject -->
  <!-- custom js for this page -->
  <script src="<?php echo e(asset('backend/assets/js/dashboard.js')); ?>"></script>
  <script src="<?php echo e(asset('backend/assets/js/datepicker.js')); ?>"></script>
    <!-- end custom js for this page -->
    <?php echo $__env->yieldPushContent('script'); ?>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\work\manobota\backend\resources\views/backend/layouts/app.blade.php ENDPATH**/ ?>